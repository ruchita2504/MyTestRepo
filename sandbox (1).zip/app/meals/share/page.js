export default function share() {
    return (
        <h1>community</h1>
    );
}